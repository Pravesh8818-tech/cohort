function printChai() {
  console.log("Hello chai");
}

function bringBrush(numberOfBrush) {
  console.log(`Hanji, le aaya ${numberOfBrush} brush`);
}

function addTwo(ekNum, doNum) {
  return ekNum + doNum;
}

bringBrush(14);
printChai();
addTwo(1, 1);
console.log(addTwo(2, 2));
