let fname = "Hitesh";
let fname2 = fname;

console.log(fname);

fname = "Piyush";

console.log(fname);
