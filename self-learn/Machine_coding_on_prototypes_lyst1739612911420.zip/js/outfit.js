// server call, rainy, cloudy, sunny

let weather = "cloudy";
let result = weather === "rainy";

if (weather === "rainy") {
  console.log("it's raining, umbrella le jaana bhai");
} else if (weather === "cloudy") {
  console.log("jacket le ja bhai");
} else if (weather === "sunny") {
  console.log("sunny h ji aaj to");
}

console.log(weather == "rainy");
