// string - "", '', ``
let name = "Rohit";
// Number - 25, 25.9
let age = 25;

// Boolean - true, false
let isPaid = true;

// undefined and null
let favoriteClass = null;
let hometown;

console.log(favoriteClass);
console.log(hometown);

// array
let skills = ["html", "CSS", "Javascript"];

// object
let studentProfile = {
  name: "Haseeb",
  age: 22,
  isPaid: true,
  skills: ["HTML", "Css", "JS"],
  favoriteClass: null,
};

console.log(typeof isPaid);
console.log(typeof skills);
console.log(typeof studentProfile);
console.log(typeof favoriteClass);
console.log(typeof hometown);
